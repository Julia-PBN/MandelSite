import { c as create_ssr_component, e as escape, a as add_attribute } from "../../chunks/index-2835083a.js";
var index_svelte_svelte_type_style_lang = /* @__PURE__ */ (() => "canvas.svelte-yim4xm{width:100%;height:100%}")();
const css = {
  code: "canvas.svelte-yim4xm{width:100%;height:100%}",
  map: null
};
const Routes = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let n = 2;
  let canvas;
  $$result.css.add(css);
  return `<h1>Mandelbrot++ coz sufferig</h1>
<br>
<p1>The value of  &#39;n&#39; in &quot;z = z^n + c&quot; is: ${escape(n)}</p1>
<br>

<input type="${"range"}" min="${"0"}" max="${"20"}" step="${"0.1"}" style="${"width: 30%"}"${add_attribute("value", n, 0)}>

<canvas id="${"Mandel"}" width="${"400"}" height="${"200"}" style="${"border: 1px; background-color:#333"}" class="${"svelte-yim4xm"}"${add_attribute("this", canvas, 0)}></canvas>`;
});
export { Routes as default };
