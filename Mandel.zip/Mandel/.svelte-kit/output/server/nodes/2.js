import * as module from '../entries/pages/index.svelte.js';

export { module };
export const index = 2;
export const entry = 'pages/index.svelte-12b90c43.js';
export const js = ["pages/index.svelte-12b90c43.js","chunks/index-ceb4870b.js"];
export const css = ["assets/pages/index.svelte-20d87bca.css"];
