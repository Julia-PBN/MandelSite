import * as module from '../entries/fallbacks/layout.svelte.js';

export { module };
export const index = 0;
export const entry = 'layout.svelte-c6fda7ad.js';
export const js = ["layout.svelte-c6fda7ad.js","chunks/index-ceb4870b.js"];
export const css = [];
