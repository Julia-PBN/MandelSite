import * as module from '../entries/fallbacks/error.svelte.js';

export { module };
export const index = 1;
export const entry = 'error.svelte-ec0b0163.js';
export const js = ["error.svelte-ec0b0163.js","chunks/index-ceb4870b.js"];
export const css = [];
